//
//  AHKActionSheetViewController.h
//  AHKActionSheetExample
//
//  Created by Arkadiusz on 09-04-14.
//  Copyright (c) 2014 Arkadiusz Holko. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AHKActionSheet;

@interface AHKActionSheetViewController : UIViewController
@property (strong, nonatomic) AHKActionSheet *actionSheet;
@end

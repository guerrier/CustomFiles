//
//  OCRichObjectStrings.m
//  ownCloud iOS library
//
//  Created by Marino Faggiana on 23/01/17.
//  Copyright © 2017 ownCloud. All rights reserved.
//

#import "OCRichObjectStrings.h"

@implementation OCRichObjectStrings

@end

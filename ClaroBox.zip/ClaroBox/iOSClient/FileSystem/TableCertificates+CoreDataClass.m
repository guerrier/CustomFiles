//
//  TableCertificates+CoreDataClass.m
//  Nextcloud
//
//  Created by Marino Faggiana on 17/02/17.
//  Copyright © 2017 TWS. All rights reserved.
//

#import "TableCertificates+CoreDataClass.h"

@implementation TableCertificates

@end

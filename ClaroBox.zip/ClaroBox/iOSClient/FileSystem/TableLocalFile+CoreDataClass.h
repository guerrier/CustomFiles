//
//  TableLocalFile+CoreDataClass.h
//  Nextcloud
//
//  Created by Marino Faggiana on 17/02/17.
//  Copyright © 2017 TWS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableLocalFile : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "TableLocalFile+CoreDataProperties.h"
